--
-- PostgreSQL database dump
--

\restrict f2ckH6cWgGqGpeFSXGnlNFQyrghOFPefynm3HwGaFK0frHc6BppL8KE6Ef93Utu

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS tags_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS password_reset_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lead_tags DROP CONSTRAINT IF EXISTS lead_tags_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lead_tags DROP CONSTRAINT IF EXISTS lead_tags_lead_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lead_requests DROP CONSTRAINT IF EXISTS lead_requests_reviewed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.lead_requests DROP CONSTRAINT IF EXISTS lead_requests_requested_by_fkey;
ALTER TABLE IF EXISTS ONLY public.lead_requests DROP CONSTRAINT IF EXISTS lead_requests_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lead_requests DROP CONSTRAINT IF EXISTS lead_requests_approved_lead_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lead_activities DROP CONSTRAINT IF EXISTS lead_activities_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lead_activities DROP CONSTRAINT IF EXISTS lead_activities_lead_id_fkey;
ALTER TABLE IF EXISTS ONLY public.email_verification_tokens DROP CONSTRAINT IF EXISTS email_verification_tokens_user_id_fkey;
DROP INDEX IF EXISTS public.ix_users_username;
DROP INDEX IF EXISTS public.ix_users_id;
DROP INDEX IF EXISTS public.ix_users_email;
DROP INDEX IF EXISTS public.ix_password_reset_tokens_user_id;
DROP INDEX IF EXISTS public.ix_password_reset_tokens_token_hash;
DROP INDEX IF EXISTS public.ix_leads_user_category;
DROP INDEX IF EXISTS public.ix_leads_id;
DROP INDEX IF EXISTS public.ix_leads_category;
DROP INDEX IF EXISTS public.ix_lead_tags_user_id;
DROP INDEX IF EXISTS public.ix_lead_requests_status;
DROP INDEX IF EXISTS public.ix_lead_requests_requested_by;
DROP INDEX IF EXISTS public.ix_lead_requests_owner_id;
DROP INDEX IF EXISTS public.ix_lead_requests_id;
DROP INDEX IF EXISTS public.ix_lead_requests_category;
DROP INDEX IF EXISTS public.ix_lead_activities_user_id;
DROP INDEX IF EXISTS public.ix_lead_activities_lead_id;
DROP INDEX IF EXISTS public.ix_lead_activities_id;
DROP INDEX IF EXISTS public.ix_email_verification_tokens_user_id;
DROP INDEX IF EXISTS public.ix_email_verification_tokens_token_hash;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS uq_user_tag;
ALTER TABLE IF EXISTS ONLY public.lead_tags DROP CONSTRAINT IF EXISTS uq_lead_tag;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS password_reset_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_pkey;
ALTER TABLE IF EXISTS ONLY public.lead_requests DROP CONSTRAINT IF EXISTS lead_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.lead_activities DROP CONSTRAINT IF EXISTS lead_activities_pkey;
ALTER TABLE IF EXISTS ONLY public.email_verification_tokens DROP CONSTRAINT IF EXISTS email_verification_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.password_reset_tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.leads ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lead_requests ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lead_activities ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.email_verification_tokens ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.tags;
DROP SEQUENCE IF EXISTS public.password_reset_tokens_id_seq;
DROP TABLE IF EXISTS public.password_reset_tokens;
DROP SEQUENCE IF EXISTS public.leads_id_seq;
DROP TABLE IF EXISTS public.leads;
DROP TABLE IF EXISTS public.lead_tags;
DROP SEQUENCE IF EXISTS public.lead_requests_id_seq;
DROP TABLE IF EXISTS public.lead_requests;
DROP SEQUENCE IF EXISTS public.lead_activities_id_seq;
DROP TABLE IF EXISTS public.lead_activities;
DROP SEQUENCE IF EXISTS public.email_verification_tokens_id_seq;
DROP TABLE IF EXISTS public.email_verification_tokens;
DROP TABLE IF EXISTS public.categories;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id character varying(50) NOT NULL,
    label character varying(255) NOT NULL,
    icon character varying(50),
    created_at timestamp without time zone,
    user_id integer NOT NULL
);


--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_verification_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used_at timestamp without time zone,
    created_at timestamp without time zone
);


--
-- Name: email_verification_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_verification_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_verification_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_verification_tokens_id_seq OWNED BY public.email_verification_tokens.id;


--
-- Name: lead_activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_activities (
    id integer NOT NULL,
    user_id integer NOT NULL,
    lead_id integer NOT NULL,
    activity_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    activity_date timestamp without time zone,
    created_at timestamp without time zone
);


--
-- Name: lead_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lead_activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lead_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lead_activities_id_seq OWNED BY public.lead_activities.id;


--
-- Name: lead_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_requests (
    id integer NOT NULL,
    owner_id integer NOT NULL,
    requested_by integer NOT NULL,
    category character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    isletme_adi character varying(255) NOT NULL,
    yetkili character varying(255),
    sehir character varying(100),
    instagram character varying(255),
    whatsapp character varying(50),
    ilk_iletisim_kanali character varying(100),
    ilk_mesaj_tarihi character varying(20),
    ilk_mesaj_saati character varying(10),
    durum character varying(100),
    oncelik character varying(20),
    takip_1 character varying(255),
    takip_2 character varying(255),
    demo_gonderildi boolean,
    demo_tarihi character varying(20),
    gorusme_tarihi character varying(20),
    gorusme_saati character varying(10),
    teklif character varying(255),
    sonuc character varying(255),
    notlar text,
    tag_ids_json text,
    rejection_note character varying(500),
    reviewed_by integer,
    reviewed_at timestamp without time zone,
    approved_lead_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: lead_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lead_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lead_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lead_requests_id_seq OWNED BY public.lead_requests.id;


--
-- Name: lead_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_tags (
    lead_id integer NOT NULL,
    tag_id character varying(50) NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leads (
    id integer NOT NULL,
    category character varying(20) NOT NULL,
    isletme_adi character varying(255) NOT NULL,
    yetkili character varying(255),
    sehir character varying(100),
    instagram character varying(255),
    whatsapp character varying(50),
    ilk_iletisim_kanali character varying(100),
    ilk_mesaj_tarihi character varying(20),
    ilk_mesaj_saati character varying(10),
    durum character varying(100),
    takip_1 character varying(255),
    takip_2 character varying(255),
    demo_gonderildi boolean,
    demo_tarihi character varying(20),
    gorusme_tarihi character varying(20),
    teklif character varying(255),
    sonuc character varying(255),
    notlar text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    user_id integer NOT NULL,
    gorusme_saati character varying(10) DEFAULT ''::character varying,
    oncelik character varying(20) DEFAULT 'orta'::character varying,
    satis_tutari numeric(12,2) DEFAULT 0,
    satis_tarihi character varying(20) DEFAULT ''::character varying
);


--
-- Name: leads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leads_id_seq OWNED BY public.leads.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used_at timestamp without time zone,
    created_at timestamp without time zone
);


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.password_reset_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.password_reset_tokens_id_seq OWNED BY public.password_reset_tokens.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    user_id integer NOT NULL,
    id character varying(50) NOT NULL,
    label character varying(255) NOT NULL,
    color character varying(20),
    is_system boolean,
    created_at timestamp without time zone
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone,
    role character varying(20) DEFAULT 'owner'::character varying,
    owner_id integer,
    account_type character varying(20) DEFAULT 'company'::character varying,
    company_name character varying(255),
    email_verified boolean DEFAULT false,
    token_version integer DEFAULT 0 NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: email_verification_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens ALTER COLUMN id SET DEFAULT nextval('public.email_verification_tokens_id_seq'::regclass);


--
-- Name: lead_activities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_activities ALTER COLUMN id SET DEFAULT nextval('public.lead_activities_id_seq'::regclass);


--
-- Name: lead_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_requests ALTER COLUMN id SET DEFAULT nextval('public.lead_requests_id_seq'::regclass);


--
-- Name: leads id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads ALTER COLUMN id SET DEFAULT nextval('public.leads_id_seq'::regclass);


--
-- Name: password_reset_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens ALTER COLUMN id SET DEFAULT nextval('public.password_reset_tokens_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, label, icon, created_at, user_id) FROM stdin;
dovme	Dövme Salonları	pen-tool	2026-07-10 14:29:39.088797	1
guzellik	Güzellik Salonları	sparkles	2026-07-10 14:29:39.088801	1
berber	Berberler	scissors	2026-07-10 14:29:39.088802	1
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_verification_tokens (id, user_id, token_hash, expires_at, used_at, created_at) FROM stdin;
1	1	95358e98b60d47716ba1c2bb7be1afe5cbc07974ad8208d35ad9033393bcd120	2026-07-16 23:44:59.151731	2026-07-14 23:45:25.661833	2026-07-14 23:44:59.154611
2	1	07a0181483c1cbb0f491900751823975485e6f7571b740a7279ffe563026391b	2026-07-16 23:49:50.13675	2026-07-14 23:50:20.369449	2026-07-14 23:49:50.139828
3	1	36a3776b8b5fc0debd1a31085ca9cfd7f2351a9df9a43b32f83223916e87e9d3	2026-07-16 23:52:53.83234	2026-07-14 23:53:09.044409	2026-07-14 23:52:53.834271
\.


--
-- Data for Name: lead_activities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_activities (id, user_id, lead_id, activity_type, title, description, activity_date, created_at) FROM stdin;
1	1	3	kayit_olusturuldu	Kayıt oluşturuldu	Roof Tattoo Studio	2026-07-10 16:06:29.247669	2026-07-10 16:06:29.249081
2	1	3	takip_yapildi	Takip yapıldı	Takip 1: 10.07.2026	2026-07-10 16:06:29.247756	2026-07-10 16:06:29.249083
3	1	3	demo_gonderildi	Demo gönderildi		2026-07-10 16:56:35.267542	2026-07-10 16:56:35.275391
4	1	2	kayit_olusturuldu	Kayıt oluşturuldu	Sefa Pertev Men's Grooming Lounge	2026-07-10 15:51:08.937001	2026-07-13 15:15:06.29922
5	1	3	teklif_verildi	Teklif verildi	8500 TL 	2026-07-13 15:16:56.577574	2026-07-13 15:16:56.581897
6	1	3	gorusme_planlandi	Görüşme saati güncellendi	2026-07-14 16:00	2026-07-14 16:00:00	2026-07-13 15:16:56.581902
7	1	4	kayit_olusturuldu	Kayıt oluşturuldu	Hakan Çapa Kuaför	2026-07-13 15:31:46.36403	2026-07-13 15:31:46.365333
8	1	4	mesaj_gonderildi	Mesaj gönderildi	Instagram DM · 2026-06-29 19:11	2026-06-29 00:00:00	2026-07-13 15:31:46.365335
9	1	4	takip_yapildi	Takip yapıldı	Takip 1: 06.07.2026	2026-07-13 15:31:46.364147	2026-07-13 15:31:46.365337
\.


--
-- Data for Name: lead_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_requests (id, owner_id, requested_by, category, status, isletme_adi, yetkili, sehir, instagram, whatsapp, ilk_iletisim_kanali, ilk_mesaj_tarihi, ilk_mesaj_saati, durum, oncelik, takip_1, takip_2, demo_gonderildi, demo_tarihi, gorusme_tarihi, gorusme_saati, teklif, sonuc, notlar, tag_ids_json, rejection_note, reviewed_by, reviewed_at, approved_lead_id, created_at, updated_at) FROM stdin;
1	1	2	berber	rejected	adsasad	asdsadsad	asdada	@aspdlawsidl	adokwğ				Yeni	orta			f							[]		1	2026-07-14 10:57:13.198765	\N	2026-07-14 10:54:00.586819	2026-07-14 10:57:13.200556
2	1	2	guzellik	approved	sadasd	sadasdas	asdasd	asdsad	asdas				Yeni	orta			f							[]		1	2026-07-14 15:22:09.478979	\N	2026-07-14 15:21:43.826286	2026-07-14 15:22:09.486546
\.


--
-- Data for Name: lead_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_tags (lead_id, tag_id, user_id) FROM stdin;
2	vip	1
3	sicak-musteri	1
4	kararsiz	1
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leads (id, category, isletme_adi, yetkili, sehir, instagram, whatsapp, ilk_iletisim_kanali, ilk_mesaj_tarihi, ilk_mesaj_saati, durum, takip_1, takip_2, demo_gonderildi, demo_tarihi, gorusme_tarihi, teklif, sonuc, notlar, created_at, updated_at, user_id, gorusme_saati, oncelik, satis_tutari, satis_tarihi) FROM stdin;
2	berber	Sefa Pertev Men's Grooming Lounge	Sefa Pertev	Sakarya	@sefapertevofficial	05369469454	Yüz yüze			Müşteri			f						2026-07-10 15:51:08.937001	2026-07-10 15:51:08.937008	1		orta	0.00	
3	dovme	Roof Tattoo Sakarya	Tuncer Urer	Sakarya 	@rooftattoogallery	05379121841	Yüz yüze			Demo Gönderildi	10.07.2026		t		2026-07-14	8500 TL 		14 Temmuz Saat 16.00 da görüşmeye gidilecek.	2026-07-10 16:06:29.244174	2026-07-13 15:19:49.325395	1	16:00	orta	0.00	
4	berber	Hakan Çapa Kuaför	Hakan Çapa	Sakarya	@hakan.capa.7	05373710809	Instagram DM	2026-06-29	19:11	Yeni	06.07.2026		f				İletişime Geçecek	Müşteri konu ile alakalı geri bildirim yapacağını söyledi.	2026-07-13 15:31:46.359096	2026-07-13 15:31:46.359103	1		orta	0.00	
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (id, user_id, token_hash, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (user_id, id, label, color, is_system, created_at) FROM stdin;
1	vip	VIP	amber	t	2026-07-13 15:25:10.98861
1	sicak-musteri	Sıcak Müşteri	orange	t	2026-07-13 15:25:10.988614
1	soguk	Soğuk	blue	t	2026-07-13 15:25:10.988615
1	kararsiz	Kararsız	purple	t	2026-07-13 15:25:10.988615
1	rakip-kullaniyor	Rakip Kullanıyor	slate	t	2026-07-13 15:25:10.988616
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, password_hash, created_at, role, owner_id, account_type, company_name, email_verified, token_version) FROM stdin;
2	testpersonel	test@behl.com	$2b$12$d2AbbG02UhrOV7dkmlTXWuNdptPWYWSQA/SHNFJ58Dtl3p5knQ34W	2026-07-14 10:50:04.774183	employee	1	company	\N	t	0
1	behlul	behlulalar@icloud.com	$2b$12$1E/UCYmVAVyOoiUfYKjve.pWTogdsCcuzWa5mtSM4UQGIJCxTXJFK	2026-07-10 14:41:25.650127	owner	\N	company	BehTech	t	0
\.


--
-- Name: email_verification_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_verification_tokens_id_seq', 3, true);


--
-- Name: lead_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lead_activities_id_seq', 12, true);


--
-- Name: lead_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lead_requests_id_seq', 2, true);


--
-- Name: leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leads_id_seq', 6, true);


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.password_reset_tokens_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (user_id, id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: lead_activities lead_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT lead_activities_pkey PRIMARY KEY (id);


--
-- Name: lead_requests lead_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_requests
    ADD CONSTRAINT lead_requests_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: lead_tags uq_lead_tag; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_tags
    ADD CONSTRAINT uq_lead_tag PRIMARY KEY (lead_id, tag_id);


--
-- Name: tags uq_user_tag; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT uq_user_tag PRIMARY KEY (user_id, id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_email_verification_tokens_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_email_verification_tokens_token_hash ON public.email_verification_tokens USING btree (token_hash);


--
-- Name: ix_email_verification_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_verification_tokens_user_id ON public.email_verification_tokens USING btree (user_id);


--
-- Name: ix_lead_activities_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lead_activities_id ON public.lead_activities USING btree (id);


--
-- Name: ix_lead_activities_lead_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lead_activities_lead_id ON public.lead_activities USING btree (lead_id);


--
-- Name: ix_lead_activities_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lead_activities_user_id ON public.lead_activities USING btree (user_id);


--
-- Name: ix_lead_requests_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lead_requests_category ON public.lead_requests USING btree (category);


--
-- Name: ix_lead_requests_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lead_requests_id ON public.lead_requests USING btree (id);


--
-- Name: ix_lead_requests_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lead_requests_owner_id ON public.lead_requests USING btree (owner_id);


--
-- Name: ix_lead_requests_requested_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lead_requests_requested_by ON public.lead_requests USING btree (requested_by);


--
-- Name: ix_lead_requests_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lead_requests_status ON public.lead_requests USING btree (status);


--
-- Name: ix_lead_tags_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lead_tags_user_id ON public.lead_tags USING btree (user_id);


--
-- Name: ix_leads_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_leads_category ON public.leads USING btree (category);


--
-- Name: ix_leads_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_leads_id ON public.leads USING btree (id);


--
-- Name: ix_leads_user_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_leads_user_category ON public.leads USING btree (user_id, category);


--
-- Name: ix_password_reset_tokens_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_password_reset_tokens_token_hash ON public.password_reset_tokens USING btree (token_hash);


--
-- Name: ix_password_reset_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_password_reset_tokens_user_id ON public.password_reset_tokens USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: email_verification_tokens email_verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lead_activities lead_activities_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT lead_activities_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: lead_activities lead_activities_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT lead_activities_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lead_requests lead_requests_approved_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_requests
    ADD CONSTRAINT lead_requests_approved_lead_id_fkey FOREIGN KEY (approved_lead_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: lead_requests lead_requests_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_requests
    ADD CONSTRAINT lead_requests_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lead_requests lead_requests_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_requests
    ADD CONSTRAINT lead_requests_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lead_requests lead_requests_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_requests
    ADD CONSTRAINT lead_requests_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: lead_tags lead_tags_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_tags
    ADD CONSTRAINT lead_tags_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: lead_tags lead_tags_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_tags
    ADD CONSTRAINT lead_tags_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tags tags_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict f2ckH6cWgGqGpeFSXGnlNFQyrghOFPefynm3HwGaFK0frHc6BppL8KE6Ef93Utu

